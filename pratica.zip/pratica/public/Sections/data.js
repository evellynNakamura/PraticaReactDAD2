

export const card = [
    {
        titulo: "Carne1",
        url: 'src/Assets/Carne1.png', 
        kg: "1",
        precoKg: "89" ,
        preco: "36"
    },
    {
        titulo: "Carne2",
        url: 'src/Assets/Carne2.png', 
        kg: "2",
        precoKg: "62" ,
        preco: "18"
    },
    {
        titulo: "Carne3",
        url: 'src/Assets/Carne3.png', 
        kg: "1",
        precoKg: "92" ,
        preco: "34"
    },
]