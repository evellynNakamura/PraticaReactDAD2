import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import CardProd from './Components/CardProd/CardProd';
import { card } from '../public/Sections/data.js'




createRoot(document.getElementById('root')).render(
  <StrictMode>
    <div>
      <CardProd
        img = {card[0].url}
        titulo={card[0].titulo}
        kg={card[0].kg}
        precoKg={card[0].precoKg}
        preco={card[0].preco}
      />

      <CardProd
        img = {card[1].url}
        titulo={card[1].titulo}
        kg={card[1].kg}
        precoKg={card[1].precoKg}
        preco={card[1].preco}
      />

      <CardProd
        img = {card[2].url}
        titulo={card[2].titulo}
        kg={card[2].kg}
        precoKg={card[2].precoKg}
        preco={card[2].preco}
      />
    </div>
    
  </StrictMode>
)
