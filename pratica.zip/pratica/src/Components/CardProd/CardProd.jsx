import styles from './CardProd.module.css'
import IconCesta from '../../assets/IconCesta'

export default function CardProd({ img, kg, precoKg, preco, titulo }) {
    return (
        <div className={styles.container}>
            <img className={styles.img} src={img} alt="" />

            <div className={styles.informacoes}>
                <h2 className={styles.titulo}>{titulo}</h2>
                <p className={styles.precoKg}>{kg}Kg/{precoKg}</p>
                <p className={styles.preco}>R$ {preco}</p>
            </div>

            <div className={styles.icone}>
                <div className={styles.cesta}> 
                    <IconCesta />
                </div>
            </div>
        </div>
    )
}